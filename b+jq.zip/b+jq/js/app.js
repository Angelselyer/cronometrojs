
class Reloj {
     
    constructor(){
           this.tiempo=0; 
           this.elemento = document.querySelectorAll(".caja");
           this.time =document.querySelector("#relojito");
           this.star =document.querySelector("button");
           this.second=[];
           this.form = document.querySelector("form")
           this.alerta =document.querySelector("#alerta");
           this.tareas = document.querySelector("#tareas2");
           this.tic=document.querySelector("#tic");
           this.alarma=document.querySelector("#alarma");
    }
    insertarEventoReloj(){
        this.elemento =Array.from(this.elemento);
        var self= this.time;
        this.elemento.forEach(a=>{
            a.addEventListener("click",function(event){
                console.log(this.time);
                self.textContent = event.target.textContent;
            })

        })
        let $self= this;
        this.star.addEventListener("click", function(){
            $self.iniciar();
        });
    }

    iniciar(a="work"){
        let tiempo=  Number.parseInt(this.time.textContent);
        this.second.push(this.tiempo = Number.parseInt(this.time.textContent));
        self=this.time;
        let $self = this;

               //Ppra los segundos 
               let caja = document.querySelector("#segundos");
               let con =60;
               let con2;
               
            switch(tiempo){
                case 5:
                    con2 = 300;
                break;
                case 10 :
                    con2 = 600;
                break;
                case 15 :
                    con2= 900;
                break;
                case 20 :
                    con2 =1200;
                break;
                case 25 :
                    con2 = 1500;
                break;
                
            }

        let timer= setInterval(function()
        {
                if(tiempo>0){
                    --tiempo;
                    //
                        if ( tiempo == 0) {
                            $self.alarma.play();
                        }    

                        if(tiempo<=0 && a =="work"){
                            $self.tic.play();
                            self.textContent =tiempo;   
                            clearInterval(timer);
                            $self.mostrarGuardado($self);

                        }else if(tiempo<=0 && a !="work"){
                           
                            clearInterval(timer);
                            $self.star.classList.remove("btn-sucess");
                            $self.star.className="btn btn-danger";
                            $self.star.textContent="Iniciar";
                            tiempo=25;   
                        };
                    }

            self.textContent =tiempo;   
        
        },60000)
        //segundos no contados

    
        let timerSeg= setInterval(function () {
            $self.tic.play();
            con2--;
            console.log(con2);
            con--; 
            if(con < 0){
                con=60
            }
            if(con2 == 0){
                clearInterval(timerSeg);
                caja.textContent =60;
            }
        caja.textContent=con;    
        
        },1000);

    }
    /*segundos (minutosTotales){
        let caja = document.querySelector("#segundos");
        let segundos = Number.parseInt(caja.textContent);
        let con =60;
        let con2;
        
        switch(minutosTotales){
            case 5:
                con2 = 300;
            break;
            case 10 :
                con2 = 600;
            break;
            case 15 :
                con2= 900;
            break;
            case 20 :
                con2 =1200;
            break;
            case 25 :
                con2 = 1500;
            break;
            
        }

        let timerSeg= setInterval(function () {
            con2--;
            console.log(con2);
            con--; 
            if(con < 0){
                con=60
            }
            if(con2 == 0){
                clearInterval(timerSeg);
                caja.textContent =60;
            }
        caja.textContent=con;    
        
        },1000)

    }*/
    descansar(){
        if(confirm("vamos a descansar?")){
           return true
        }
        return false;
    }
   /* modoDescanso(){
        this.time.textContent=5;
        this.star.classList.remove("btn-danger");
        this.star.className="btn btn-success";
        this.star.textContent="Descansando";
        this.iniciar("a");
    }*/
    guardar(tarea){
       
        let posicion= localStorage.length; 
        let posicionT = this.second.length;

        localStorage.setItem("Tarea"+posicion,tarea); 
        localStorage.setItem("Tiempo"+posicion,this.second[posicionT-1]);

        this.dibujarTareas();
    }

    sonar(hora=5){
        return "aaaaaaaaa";
    }
    mostrarGuardado(a){
        this.form.classList.remove("d-none");
        self=this;
            document.querySelector("#guardado").addEventListener("click",function(event){
                event.preventDefault();
                let valor= document.querySelector("input").value.trim();
            if(valor){            
                self.guardar(valor);
                document.querySelector("input").value="";
                self.alerta.classList.remove("d-none");
                    setTimeout(self.ocultarGuardado,500)
            }
        });

    }
    ocultarGuardado(){ 
        this.alerta.className="d-none alert alert-success";
        this.form.className="mt-1 d-none";
    }
    dibujarTareas(){
        let insertar="";
        if(localStorage.length>2){
            for(let i=1; i<localStorage.length; i++)
            {
                if(i%2 != 0   ) { 
                    insertar+=`<tr> <td> ${localStorage["Tiempo"+i]}</td> <td> ${localStorage["Tarea"+i]}</td></tr> `;
                }

            }

            this.tareas.innerHTML=insertar;
        }
    }
}
var reloj;
window.onload =function(){
    reloj= new Reloj;
    reloj.insertarEventoReloj();
    reloj.dibujarTareas();
    if(!localStorage.contador){
        localStorage.contador=0;
    }
}

function limpiar() {
    localStorage.clear();
    localStorage.contador=0;
    reloj.dibujarTareas();
}